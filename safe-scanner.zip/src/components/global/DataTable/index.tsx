import React from "react";

function DataTable() {
  return <div>DataTable</div>;
}

export default DataTable;
